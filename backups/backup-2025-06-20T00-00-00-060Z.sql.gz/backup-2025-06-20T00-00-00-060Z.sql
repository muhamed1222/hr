PRAGMA foreign_keys=OFF;
BEGIN TRANSACTION;
CREATE TABLE system_config (
    key TEXT PRIMARY KEY NOT NULL,
    value TEXT,
    type TEXT NOT NULL DEFAULT 'string' CHECK(type IN ('string', 'number', 'boolean', 'json', 'time', 'date')),
    category TEXT NOT NULL DEFAULT 'general',
    title TEXT NOT NULL,
    description TEXT,
    isEditable BOOLEAN NOT NULL DEFAULT 1,
    isSystem BOOLEAN NOT NULL DEFAULT 0,
    validation TEXT,
    defaultValue TEXT,
    updatedBy INTEGER,
    createdAt DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updatedAt DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, organizationId INTEGER,
    
    FOREIGN KEY (updatedBy) REFERENCES users(id) ON DELETE SET NULL
);
INSERT INTO system_config VALUES('work.start_time','09:00','time','work_schedule','Начало рабочего дня','Время начала рабочего дня по умолчанию',1,0,'{"pattern": "^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$"}',NULL,NULL,'2025-06-19 20:17:55','2025-06-19 20:17:55',1);
INSERT INTO system_config VALUES('work.end_time','18:00','time','work_schedule','Конец рабочего дня','Время окончания рабочего дня по умолчанию',1,0,'{"pattern": "^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$"}',NULL,NULL,'2025-06-19 20:17:55','2025-06-19 20:17:55',1);
INSERT INTO system_config VALUES('work.lunch_start','13:00','time','work_schedule','Начало обеда','Время начала обеденного перерыва',1,0,'{"pattern": "^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$"}',NULL,NULL,'2025-06-19 20:17:55','2025-06-19 20:17:55',1);
INSERT INTO system_config VALUES('work.lunch_end','14:00','time','work_schedule','Конец обеда','Время окончания обеденного перерыва',1,0,'{"pattern": "^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$"}',NULL,NULL,'2025-06-19 20:17:55','2025-06-19 20:17:55',1);
INSERT INTO system_config VALUES('work.late_threshold','15','number','work_schedule','Лимит опозданий (минуты)','Количество минут опоздания, после которого считается нарушением',1,0,'{"min": 0, "max": 120}',NULL,NULL,'2025-06-19 20:17:55','2025-06-19 20:17:55',1);
INSERT INTO system_config VALUES('notifications.enabled','true','boolean','notifications','Включить уведомления','Глобальное включение/отключение системы уведомлений',1,0,NULL,NULL,NULL,'2025-06-19 20:17:55','2025-06-19 20:17:55',1);
INSERT INTO system_config VALUES('notifications.reminder_enabled','true','boolean','notifications','Автонапоминания','Включить автоматические напоминания о заполнении логов',1,0,NULL,NULL,NULL,'2025-06-19 20:17:55','2025-06-19 20:17:55',1);
INSERT INTO system_config VALUES('notifications.reminder_time','17:30','time','notifications','Время напоминаний','Время отправки ежедневных напоминаний',1,0,NULL,NULL,NULL,'2025-06-19 20:17:55','2025-06-19 20:17:55',1);
INSERT INTO system_config VALUES('notifications.late_warning_enabled','true','boolean','notifications','Уведомления об опозданиях','Отправлять уведомления при опозданиях',1,0,NULL,NULL,NULL,'2025-06-19 20:17:55','2025-06-19 20:17:55',1);
INSERT INTO system_config VALUES('notifications.absence_approval_enabled','true','boolean','notifications','Уведомления о заявках','Уведомлять менеджеров о новых заявках на отсутствие',1,0,NULL,NULL,NULL,'2025-06-19 20:17:55','2025-06-19 20:17:55',1);
INSERT INTO system_config VALUES('templates.reminder_message','Привет! 👋\n\nНе забудь заполнить рабочий лог на сегодня ({date}).\n\n⏰ Рабочий день: {start_time} - {end_time}\n📝 Заполни через /start','string','message_templates','Шаблон напоминания','Текст автоматического напоминания о заполнении лога',1,0,NULL,NULL,NULL,'2025-06-19 20:17:55','2025-06-19 20:17:55',1);
INSERT INTO system_config VALUES('templates.late_warning','⚠️ Опоздание зафиксировано\n\nПришёл: {actual_time}\nДолжен был: {expected_time}\nОпоздание: {late_minutes} мин.','string','message_templates','Уведомление об опоздании','Текст уведомления при опоздании',1,0,NULL,NULL,NULL,'2025-06-19 20:17:55','2025-06-19 20:17:55',1);
INSERT INTO system_config VALUES('templates.absence_created','📝 Новая заявка на отсутствие\n\nСотрудник: {employee_name}\nТип: {absence_type}\nПериод: {start_date} - {end_date}\nПричина: {reason}','string','message_templates','Новая заявка на отсутствие','Уведомление менеджерам о новой заявке',1,0,NULL,NULL,NULL,'2025-06-19 20:17:55','2025-06-19 20:17:55',1);
INSERT INTO system_config VALUES('templates.absence_approved','✅ Заявка одобрена\n\nТип: {absence_type}\nПериод: {start_date} - {end_date}\nОдобрил: {approver_name}','string','message_templates','Заявка одобрена','Уведомление сотруднику об одобрении заявки',1,0,NULL,NULL,NULL,'2025-06-19 20:17:55','2025-06-19 20:17:55',1);
INSERT INTO system_config VALUES('templates.absence_rejected','❌ Заявка отклонена\n\nТип: {absence_type}\nПериод: {start_date} - {end_date}\nПричина отказа: {rejection_reason}','string','message_templates','Заявка отклонена','Уведомление сотруднику об отклонении заявки',1,0,NULL,NULL,NULL,'2025-06-19 20:17:55','2025-06-19 20:17:55',1);
INSERT INTO system_config VALUES('system.timezone','Europe/Moscow','string','system','Часовой пояс','Часовой пояс системы по умолчанию',1,1,NULL,NULL,NULL,'2025-06-19 20:17:55','2025-06-19 20:17:55',1);
INSERT INTO system_config VALUES('system.date_format','DD.MM.YYYY','string','system','Формат даты','Формат отображения дат в интерфейсе',1,0,NULL,NULL,NULL,'2025-06-19 20:17:55','2025-06-19 20:17:55',1);
INSERT INTO system_config VALUES('system.time_format','HH:mm','string','system','Формат времени','Формат отображения времени в интерфейсе',1,0,NULL,NULL,NULL,'2025-06-19 20:17:55','2025-06-19 20:17:55',1);
INSERT INTO system_config VALUES('system.week_start','1','number','system','Начало недели','День начала недели (1=Понедельник, 0=Воскресенье)',1,0,NULL,NULL,NULL,'2025-06-19 20:17:55','2025-06-19 20:17:55',1);
INSERT INTO system_config VALUES('system.max_upload_size','10','number','system','Макс. размер файла (МБ)','Максимальный размер загружаемых файлов в мегабайтах',1,1,NULL,NULL,NULL,'2025-06-19 20:17:55','2025-06-19 20:17:55',1);
INSERT INTO system_config VALUES('access.allow_self_edit','true','boolean','access_control','Самостоятельное редактирование','Разрешить сотрудникам редактировать собственные логи',1,0,NULL,NULL,NULL,'2025-06-19 20:17:55','2025-06-19 20:17:55',1);
INSERT INTO system_config VALUES('access.edit_deadline_hours','24','number','access_control','Срок редактирования (часы)','Количество часов после создания записи, в течение которых можно редактировать',1,0,'{"min": 1, "max": 168}',NULL,NULL,'2025-06-19 20:17:55','2025-06-19 20:17:55',1);
INSERT INTO system_config VALUES('access.manager_override','true','boolean','access_control','Переопределение менеджером','Разрешить менеджерам редактировать любые записи своей команды',1,0,NULL,NULL,NULL,'2025-06-19 20:17:55','2025-06-19 20:17:55',1);
INSERT INTO system_config VALUES('access.admin_full_access','true','boolean','access_control','Полный доступ админов','Предоставить администраторам полный доступ ко всем данным',1,1,NULL,NULL,NULL,'2025-06-19 20:17:55','2025-06-19 20:17:55',1);
INSERT INTO system_config VALUES('telegram.bot_enabled','true','boolean','integrations','Telegram бот','Включить Telegram бота для уведомлений',1,1,NULL,NULL,NULL,'2025-06-19 20:17:55','2025-06-19 20:17:55',1);
INSERT INTO system_config VALUES('telegram.deep_links_enabled','true','boolean','integrations','Deep Links','Включить глубокие ссылки в Telegram уведомлениях',1,0,NULL,NULL,NULL,'2025-06-19 20:17:55','2025-06-19 20:17:55',1);
INSERT INTO system_config VALUES('email.enabled','false','boolean','integrations','Email уведомления','Включить отправку уведомлений по email',1,1,NULL,NULL,NULL,'2025-06-19 20:17:55','2025-06-19 20:17:55',1);
INSERT INTO system_config VALUES('slack.enabled','false','boolean','integrations','Slack интеграция','Включить интеграцию со Slack',1,1,NULL,NULL,NULL,'2025-06-19 20:17:55','2025-06-19 20:17:55',1);
INSERT INTO system_config VALUES('analytics.retention_days','365','number','analytics','Хранение данных (дни)','Количество дней хранения аналитических данных',1,1,NULL,NULL,NULL,'2025-06-19 20:17:55','2025-06-19 20:17:55',1);
INSERT INTO system_config VALUES('reports.auto_generate','true','boolean','analytics','Автоотчёты','Автоматическая генерация еженедельных отчётов',1,0,NULL,NULL,NULL,'2025-06-19 20:17:55','2025-06-19 20:17:55',1);
INSERT INTO system_config VALUES('reports.send_to_managers','true','boolean','analytics','Отправка менеджерам','Автоматически отправлять отчёты менеджерам команд',1,0,NULL,NULL,NULL,'2025-06-19 20:17:55','2025-06-19 20:17:55',1);
INSERT INTO system_config VALUES('performance.cache_duration','300','number','analytics','Кэширование (секунды)','Время кэширования аналитических данных в секундах',1,1,NULL,NULL,NULL,'2025-06-19 20:17:55','2025-06-19 20:17:55',1);
CREATE TABLE organizations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    slug TEXT UNIQUE NOT NULL,
    description TEXT,
    settings TEXT DEFAULT '{}',
    contactInfo TEXT,
    telegramBotToken TEXT,
    telegramSettings TEXT DEFAULT '{}',
    isActive BOOLEAN NOT NULL DEFAULT 1,
    maxUsers INTEGER,
    subscriptionType TEXT NOT NULL DEFAULT 'free' CHECK(subscriptionType IN ('free', 'basic', 'premium', 'enterprise')),
    subscriptionExpiresAt DATETIME,
    timezone TEXT NOT NULL DEFAULT 'Europe/Moscow',
    locale TEXT NOT NULL DEFAULT 'ru',
    ownerId INTEGER,
    createdAt DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updatedAt DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (ownerId) REFERENCES users(id) ON DELETE SET NULL
);
INSERT INTO organizations VALUES(1,'Outcast Company','outcast-company','Демонстрационная организация TimeBot','{"logo": "/logo.png", "primaryColor": "#3B82F6", "secondaryColor": "#1F2937", "companyName": "Outcast Company"}',NULL,NULL,'{}',1,NULL,'enterprise',NULL,'Europe/Moscow','ru',NULL,'2025-06-19 20:26:58','2025-06-19 20:26:58');
INSERT INTO organizations VALUES(2,'Tech Startup','tech-startup','Технологический стартап','{"logo": "/demo-logos/tech.png", "primaryColor": "#10B981", "secondaryColor": "#065F46", "companyName": "Tech Startup"}',NULL,NULL,'{}',1,50,'premium',NULL,'Europe/Moscow','ru',NULL,'2025-06-19 20:26:58','2025-06-19 20:26:58');
INSERT INTO organizations VALUES(3,'Marketing Agency','marketing-agency','Маркетинговое агентство','{"logo": "/demo-logos/marketing.png", "primaryColor": "#8B5CF6", "secondaryColor": "#4C1D95", "companyName": "Marketing Agency"}',NULL,NULL,'{}',1,25,'basic',NULL,'Europe/London','en',NULL,'2025-06-19 20:26:58','2025-06-19 20:26:58');
INSERT INTO organizations VALUES(4,'Consulting Group','consulting-group','Консалтинговая группа','{"logo": "/demo-logos/consulting.png", "primaryColor": "#F59E0B", "secondaryColor": "#92400E", "companyName": "Consulting Group"}',NULL,NULL,'{}',1,100,'enterprise',NULL,'America/New_York','en',NULL,'2025-06-19 20:26:58','2025-06-19 20:26:58');
CREATE TABLE organization_files (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    organizationId INTEGER NOT NULL,
    fileName TEXT NOT NULL,
    filePath TEXT NOT NULL,
    fileType TEXT NOT NULL,
    fileSize INTEGER NOT NULL,
    uploadedBy INTEGER,
    isPublic BOOLEAN NOT NULL DEFAULT 0,
    createdAt DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updatedAt DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (organizationId) REFERENCES organizations(id) ON DELETE CASCADE,
    FOREIGN KEY (uploadedBy) REFERENCES users(id) ON DELETE SET NULL
);
CREATE TABLE telegram_bots (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    organizationId INTEGER NOT NULL,
    botToken TEXT NOT NULL,
    botUsername TEXT,
    botName TEXT,
    isActive BOOLEAN NOT NULL DEFAULT 1,
    webhookUrl TEXT,
    settings TEXT DEFAULT '{}',
    lastError TEXT,
    lastErrorAt DATETIME,
    createdAt DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updatedAt DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (organizationId) REFERENCES organizations(id) ON DELETE CASCADE
);
INSERT INTO telegram_bots VALUES(1,1,'demo-token','timebot_demo','TimeBot Demo',1,NULL,'{"allowDeepLinks": true, "sendNotifications": true}',NULL,NULL,'2025-06-19 20:26:58','2025-06-19 20:26:58');
DELETE FROM sqlite_sequence;
INSERT INTO sqlite_sequence VALUES('organizations',4);
INSERT INTO sqlite_sequence VALUES('telegram_bots',1);
CREATE INDEX idx_system_config_category ON system_config(category);
CREATE INDEX idx_system_config_editable ON system_config(isEditable);
CREATE INDEX idx_system_config_system ON system_config(isSystem);
CREATE INDEX idx_organizations_slug ON organizations(slug);
CREATE INDEX idx_organizations_active ON organizations(isActive);
CREATE INDEX idx_organizations_subscription ON organizations(subscriptionType);
CREATE INDEX idx_organizations_owner ON organizations(ownerId);
CREATE INDEX idx_system_config_organization ON system_config(organizationId);
CREATE INDEX idx_organization_files_org ON organization_files(organizationId);
CREATE INDEX idx_organization_files_type ON organization_files(fileType);
CREATE INDEX idx_organization_files_public ON organization_files(isPublic);
CREATE INDEX idx_telegram_bots_org ON telegram_bots(organizationId);
CREATE INDEX idx_telegram_bots_active ON telegram_bots(isActive);
CREATE UNIQUE INDEX idx_telegram_bots_token ON telegram_bots(botToken);
COMMIT;
